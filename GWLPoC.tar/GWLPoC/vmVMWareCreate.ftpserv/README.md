=============
Playbook Name
=============
Playbook to create a Redhat RHEL6 or RHEL7 instance on VMWare. 

Usage
-----
0. See README.md for possible variable combinations and define host to DNS and LDAP before starting build
1. git clone git@fss-build10nb.gwl.com:ITSUNIX/vmVMWareCreate.git
2. cd vmVMWareCreate/
3. vi vars/create.yml  (Update VM Specific Variables)
4. vi inventory/hosts  (Update Guest hostnmame - fqdn)
5. ansible-playbook -i inventory/hosts  site.yml

Revisions
---------
+ 2017        Original version was the result of the Automation POC
+ 2018/07/17  Refactored to remove some of the "Non" production issues - Stored id/password, abilitity to build in more than Tier2
+ 2018/07/18  Variable naming convention cleanup in playbooks and roles.
+ 2018/07/26  Merged v1 branch back to master. We now have a functional productionish Playbook.


VSphere Variable Options
========================
Denver TIER1
------------
VSPHERE_HOST: 'appvrtctr01p.its.corp.gwl.com' 
DATACENTER: 'Denver'
CLUSTER: 'Denver-Tier1-UNIX'
TEMPLATE: 'tmpl-rhel7-2017071901-Denver-tier1'
FOLDER: '/Servers/UNIX/Production'
POOL: 'Denver-Tier1-UNIX'
NETWORK: 'prod-denver-ucs-???'  Ex: prod-denver-ucs-102 or prod-denver-ucs-127
 
Denver TIER2
------------
VSPHERE_HOST: 'appvrtctr01p.its.corp.gwl.com' 
DATACENTER: 'Denver'
CLUSTER: 'Denver-Tier2-UNIX'
TEMPLATE: 'tmpl-rhel7-2017071901-Denver-tier2'
FOLDER: '/Servers/UNIX/Production'
POOL: 'Denver-Tier2-UNIX'
NETWORK: 'prod-denver-unix-???'

VCenter Servers
---------------
appvrtctr01p.its.corp.gwl.com  - Denver
appvrtctr01r.its.corp.gwl.com  - Andover

Unix Templates
--------------
tmpl-rhel7-2017071901-Denver-tier1
tmpl-rhel7-2017071901-Andover-tier1
tmpl-rhel7-2017071901-Denver-tier2

Datacenters
-----------
Denver
Andover

Clusters
--------
Denver-Tier1-Unix
Denver-Tier2-Unix
Denver-Tier2-DMZ

