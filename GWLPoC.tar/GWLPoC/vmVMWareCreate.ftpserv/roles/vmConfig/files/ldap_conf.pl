#!/usr/bin/perl

use strict;
use warnings;

my $AUTHCONFIG = "/usr/sbin/authconfig";

&AuthConfig();

sub AuthConfig() {
   my $result = 0;
   my $value = (time() % 2);

   my $cmd = "$AUTHCONFIG --update --enableldap --enableldaptls --enablemd5 --enablemkhomedir";
      $cmd = "$cmd"." --enablelocauthorize --enableldapauth";
      if ($value == 0) {
          $cmd = "$cmd"." --ldapserver ldap6.itssrv.com,ldap5.itssrv.com,";
      }
      else {
          $cmd = "$cmd"." --ldapserver ldap5.itssrv.com,ldap6.itssrv.com,";
      }
      $cmd = "$cmd"."ldap8.itssrv.com --ldapbasedn dc=gwl,dc=com";

   print "\nExecuting authconfig command!\n\n";
   $result = system("$cmd");
   if($result != 0) {
      print "Command authconfig failed!\n";
      exit(1);
   }
}
